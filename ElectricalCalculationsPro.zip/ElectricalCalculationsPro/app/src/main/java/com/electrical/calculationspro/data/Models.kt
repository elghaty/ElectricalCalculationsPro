package com.electrical.calculationspro.data

enum class Standard { IEC, EGYPTIAN, CEI, NEC, CEC }

enum class CurrentType {
    DirectCurrent,
    AlternatingSinglePhase,
    AlternatingTwoPhase,
    AlternatingThreePhase
}

enum class ConductorMaterial { Copper, Aluminum }

enum class InsulationType { PVC, XLPE, EPR, Rubber }

data class InstallationMethod(
    val code: String,
    val description: String
)

val iecInstallationMethods = IecTables.allInstallationMethods

// Keep old for compatibility if needed
val _oldIecMethods = listOf(
    InstallationMethod("1 - A1", "Single-core"),
    InstallationMethod("1 - A2", "Multi-core"),
    InstallationMethod("2 - B1", "Single-core in conduit"),
    InstallationMethod("2 - B2", "Multi-core in conduit"),
    InstallationMethod("3 - C", "On wall"),
    InstallationMethod("4 - D1", "In ground"),
    InstallationMethod("4 - D2", "In duct in ground"),
    InstallationMethod("5 - E", "In free air"),
    InstallationMethod("6 - F", "On perforated tray"),
    InstallationMethod("7 - G", "On ladder")
)

data class ConductorSizingInput(
    val currentType: CurrentType = CurrentType.AlternatingSinglePhase,
    val voltage: Double = 230.0,
    val load: Double = 5000.0, // Watts
    val powerFactor: Double = 0.9,
    val lineLength: Double = 60.0, // meters
    val installationMethod: InstallationMethod = iecInstallationMethods[0],
    val ambientTemp: Double = 30.0, // °C
    val conductor: ConductorMaterial = ConductorMaterial.Copper,
    val insulation: InsulationType = InsulationType.PVC,
    val circuitsInConduit: Int = 1,
    val maxVoltageDrop: Double = 4.0 // %
)

data class ConductorSizingResult(
    val designCurrent: Double,          // Ib
    val recommendedSection: Double,     // mm²
    val selectedSection: Double,        // mm² (next standard)
    val ampacity: Double,               // Iz
    val voltageDropPercent: Double,
    val voltageDropVolts: Double,
    val protectiveDevice: Double,       // recommended breaker/fuse
    val notes: List<String>
)

// Standard cross sections (mm²)
val standardSections = listOf(
    1.5, 2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 35.0, 50.0,
    70.0, 95.0, 120.0, 150.0, 185.0, 240.0, 300.0, 400.0
)
