package com.electrical.calculationspro.data

import kotlin.math.sqrt

object ElectricalCalculations {

    /**
     * Calculate design current Ib (A)
     */
    fun calculateDesignCurrent(
        loadWatts: Double,
        voltage: Double,
        powerFactor: Double,
        currentType: CurrentType
    ): Double {
        return when (currentType) {
            CurrentType.DirectCurrent -> loadWatts / voltage
            CurrentType.AlternatingSinglePhase -> loadWatts / (voltage * powerFactor)
            CurrentType.AlternatingTwoPhase -> loadWatts / (voltage * powerFactor * sqrt(2.0))
            CurrentType.AlternatingThreePhase -> loadWatts / (voltage * powerFactor * sqrt(3.0))
        }
    }

    /**
     * Voltage drop calculation
     * Approximate using resistance + reactance
     */
    fun calculateVoltageDrop(
        current: Double,
        length: Double,
        sectionMm2: Double,
        powerFactor: Double,
        currentType: CurrentType,
        material: ConductorMaterial,
        voltage: Double
    ): Pair<Double, Double> {
        val resistivity = if (material == ConductorMaterial.Copper) 0.0225 else 0.036 // ohm.mm²/m at ~70°C
        val r = resistivity / sectionMm2 // Ω/m
        val x = 0.08 / 1000.0 // approximate reactance Ω/m

        val cosPhi = powerFactor.coerceIn(0.0, 1.0)
        val sinPhi = sqrt((1 - cosPhi * cosPhi).coerceAtLeast(0.0))

        val factor = when (currentType) {
            CurrentType.DirectCurrent -> 2.0
            CurrentType.AlternatingSinglePhase -> 2.0
            CurrentType.AlternatingTwoPhase -> 2.0
            CurrentType.AlternatingThreePhase -> sqrt(3.0)
        }

        val dropVolts = factor * current * length * (r * cosPhi + x * sinPhi)
        val dropPercent = (dropVolts / voltage) * 100.0

        return dropPercent to dropVolts
    }

    /**
     * Main conductor sizing using FULL IEC 60364-5-52 tables
     * Works for both IEC and Egyptian Code (الكود المصري)
     */
    fun sizeConductor(
        input: ConductorSizingInput,
        standard: Standard = Standard.IEC
    ): ConductorSizingResult {

        val ib = calculateDesignCurrent(
            input.load,
            input.voltage,
            input.powerFactor,
            input.currentType
        )

        val methodKey = IecTables.methodToKey(input.installationMethod.code)

        // Number of loaded conductors
        val loadedConductors = when (input.currentType) {
            CurrentType.DirectCurrent, CurrentType.AlternatingSinglePhase -> 2
            CurrentType.AlternatingTwoPhase -> 2
            CurrentType.AlternatingThreePhase -> 3
        }

        val tempFactor = if (input.insulation == InsulationType.XLPE || input.insulation == InsulationType.EPR)
            IecTables.ambientCorrectionXlpe(input.ambientTemp)
        else
            IecTables.ambientCorrectionPvc(input.ambientTemp)
        val groupFactor = IecTables.groupingFactor(input.circuitsInConduit)

        // Required Iz after correction factors
        // Iz ≥ Ib / (Ca × Cg)
        val requiredIz = ib / (tempFactor * groupFactor)

        var selectedSection = 1.5
        var ampacity = 0.0
        var vdPercent = 100.0
        var vdVolts = 0.0
        var found = false

        for (section in standardSections) {
            val baseIz = IecTables.getBaseAmpacity(
                section = section,
                method = methodKey,
                loadedConductors = loadedConductors,
                material = input.conductor,
                insulation = input.insulation
            )

            // Apply correction factors
            ampacity = baseIz * tempFactor * groupFactor

            if (ampacity < requiredIz) continue

            // Check voltage drop
            val (percent, volts) = calculateVoltageDrop(
                current = ib,
                length = input.lineLength,
                sectionMm2 = section,
                powerFactor = input.powerFactor,
                currentType = input.currentType,
                material = input.conductor,
                voltage = input.voltage
            )

            if (percent <= input.maxVoltageDrop) {
                selectedSection = section
                vdPercent = percent
                vdVolts = volts
                found = true
                break
            }
        }

        // If no section satisfied voltage drop, take the largest that satisfies ampacity
        if (!found) {
            for (section in standardSections.reversed()) {
                val baseIz = IecTables.getBaseAmpacity(section, methodKey, loadedConductors, input.conductor, input.insulation)
                ampacity = baseIz * tempFactor * groupFactor
                if (ampacity >= requiredIz) {
                    selectedSection = section
                    val (percent, volts) = calculateVoltageDrop(
                        ib, input.lineLength, section, input.powerFactor,
                        input.currentType, input.conductor, input.voltage
                    )
                    vdPercent = percent
                    vdVolts = volts
                    break
                }
            }
        }

        // Protective device (next standard rating ≥ Ib)
        val standardBreakers = listOf(
            6.0, 10.0, 16.0, 20.0, 25.0, 32.0, 40.0, 50.0,
            63.0, 80.0, 100.0, 125.0, 160.0, 200.0, 250.0, 315.0, 400.0
        )
        val protective = standardBreakers.firstOrNull { it >= ib } ?: (ib * 1.25)

        val notes = mutableListOf<String>()
        notes.add("Ib = ${"%.2f".format(ib)} A")
        notes.add("Required Iz ≈ ${"%.1f".format(requiredIz)} A")
        notes.add("Selected S = $selectedSection mm²")
        notes.add("Iz (after factors) ≈ ${"%.1f".format(ampacity)} A")
        notes.add("ΔU = ${"%.2f".format(vdPercent)} % (${"%.2f".format(vdVolts)} V)")
        notes.add("Method: ${input.installationMethod.code} → $methodKey")
        notes.add("Ca (temp) = ${"%.2f".format(tempFactor)} | Cg (group) = ${"%.2f".format(groupFactor)}")

        when (standard) {
            Standard.EGYPTIAN -> {
                notes.add("حسب الكود المصري (مبني على IEC 60364-5-52)")
                notes.add("الجداول المستخدمة: Table B.52.2 / B.52.4")
            }
            Standard.IEC -> {
                notes.add("According to IEC 60364-5-52 (full tables)")
                notes.add("Tables: B.52.2 / B.52.4 + correction factors")
            }
            else -> notes.add("Simplified – verify with official standard")
        }

        if (vdPercent > input.maxVoltageDrop) {
            notes.add("⚠ هبوط الجهد أكبر من الحد المسموح")
        }

        return ConductorSizingResult(
            designCurrent = ib,
            recommendedSection = selectedSection,
            selectedSection = selectedSection,
            ampacity = ampacity,
            voltageDropPercent = vdPercent,
            voltageDropVolts = vdVolts,
            protectiveDevice = protective,
            notes = notes
        )
    }
}
